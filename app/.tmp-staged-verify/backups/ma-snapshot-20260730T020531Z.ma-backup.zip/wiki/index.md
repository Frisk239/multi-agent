# Wiki Index

## Pages
- [答辩 Demo Script 排练（≤10 min）](FRI-05-答辩-Demo-Script-排练（≤10-min）.md) — FRI-05（2026-07-19）
- [Memory 检索面板 mock（Should）](FRI-04-Memory-检索面板-mock（Should）.md) — FRI-04（2026-07-19）
- [Agent runtime 适配调研（Pi / Claude / opencode）](FRI-07-Agent-runtime-适配调研（Pi--Claude--opencode）.md) — FRI-07（2026-07-19）
- [Wiki 架构占位与 llm-wiki-pattern 对齐](FRI-08-Wiki-架构占位与-llm-wiki-pattern-对齐.md) — FRI-08（2026-07-19）
- [Page Global Only](query-Page-Global-Only.md) — query（2026-07-22）
- [巡检 2026-07-19](FRI-47-巡检-2026-07-19.md) — FRI-47（2026-07-24）
- [B3 mention no leader](FRI-56-B3-mention-no-leader.md) — FRI-56（2026-07-24）
