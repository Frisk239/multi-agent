# FRI-07: Agent runtime 适配调研（Pi / Claude / opencode）

## 概述
本 Issue 完成了对 Agent runtime 适配方案的调研，重点评估了 Pi、Claude 与 opencode 的兼容性与集成路径。调研明确了当前 Cursor 仅作为 UI mock 的定位，Phase 1 实装工作暂未展开。

## 做了什么
- 调研 Pi、Claude、opencode 等 Agent runtime 的适配可行性与技术差异。
- 评估现有 UI 层与 runtime 的解耦需求。
- 确认 Cursor 当前状态为纯 UI mock，不涉及真实 runtime 调用。

## 关键决策
- **Cursor 定位**：仅作为 UI mock 使用，不承载实际 Agent runtime 逻辑。
- **Phase 1 范围**：实装工作（真实 runtime 集成）标记为 TBD，后续单独规划。
- **适配策略**：优先完成调研输出，为后续 Phase 提供决策依据，避免过早绑定具体实现。

## 产出
- 完成 Agent runtime（Pi / Claude / opencode）适配调研结论。
- 明确 Cursor 仅 UI mock 的阶段性决策。
- Phase 1 实装工作项标记为 TBD，待后续 Issue 跟进。