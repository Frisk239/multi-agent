# Issue FRI-56: B3 mention no leader

**Summary**  
This issue addressed the inability to perform @mention-based assignments and distributions in the B3 (product squad) due to the absence of a designated leader in the squad details.

**What was done**  
- Identified that the product squad lacked a team leader, blocking @mention feature usage for task delegation.  
- Updated the squad configuration to include a specified leader (captain).  
- Verified and enabled mention distribution functionality.

**Key decisions**  
- Leader must be explicitly designated in the squad details page to activate @mention派发 (mention broadcasting) for the squad.  
- No alternative workarounds were implemented; direct configuration change was the required fix.

**Output**  
- Squad details now include a designated leader, resolving the mention distribution blockage.  
- Issue status: **Done** (closed by 林远).  

*Referenced from issue comments and status change log.*